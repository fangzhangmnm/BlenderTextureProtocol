"""Stub av module — satisfies aiortc import targets without shipping
ffmpeg. DataChannel-only paths never invoke these classes at runtime.
Raises AttributeError loudly if media codepaths are ever exercised."""
class AudioFrame: pass
class VideoFrame: pass
class AudioResampler: pass
class CodecContext: pass
class AudioCodecContext: pass
