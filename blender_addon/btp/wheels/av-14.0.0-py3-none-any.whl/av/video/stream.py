class VideoStream: pass
