class VideoCodecContext: pass
