class AudioStream: pass
