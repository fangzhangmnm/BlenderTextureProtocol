class Packet: pass
