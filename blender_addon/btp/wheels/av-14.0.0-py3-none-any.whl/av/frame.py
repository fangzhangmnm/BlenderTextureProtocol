class Frame: pass
